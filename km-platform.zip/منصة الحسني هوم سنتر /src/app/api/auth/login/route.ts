import { NextResponse } from "next/server";
import { z } from "zod";
import { env } from "@/lib/env";
import { signSession, setSessionCookie, verifyPassword } from "@/lib/auth";
import { findDemoUserByEmail } from "@/lib/data/users";
import type { SessionUser } from "@/lib/types";

const schema = z.object({
  email: z.string().min(1, "البريد الإلكتروني أو الرقم الوظيفي مطلوب"),
  password: z.string().min(1, "كلمة المرور مطلوبة"),
});

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.errors[0].message }, { status: 400 });
  }
  const { email, password } = parsed.data;

  // المسار الموحّد عبر Supabase Auth (هوية مشتركة مع نظام Home Center).
  if (env.authProvider === "supabase") {
    const { createSupabaseServerClient } = await import("@/lib/supabase/server");
    const { mapSupabaseRole, mapSupabaseDept } = await import("@/lib/supabase/roleMap");
    const supabase = createSupabaseServerClient();
    const { data, error } = await supabase.auth.signInWithPassword({
      email: email.trim().toLowerCase(),
      password,
    });
    if (error || !data.user) {
      return NextResponse.json({ error: "بيانات الدخول غير صحيحة." }, { status: 401 });
    }
    const { data: profile } = await supabase
      .from("user_profiles")
      .select("full_name, role")
      .eq("id", data.user.id)
      .maybeSingle();
    const p = profile as { full_name?: string; role?: string } | null;
    const dept = mapSupabaseDept(p?.role);
    const su: SessionUser = {
      id: data.user.id,
      employeeNo: "",
      name: p?.full_name ?? data.user.email ?? "مستخدم",
      email: data.user.email ?? "",
      role: mapSupabaseRole(p?.role),
      title: null,
      departmentId: dept?.id ?? null,
      departmentName: dept?.name ?? null,
      avatarColor: "#17B8A1",
    };
    return NextResponse.json({ user: su });
  }

  let sessionUser: SessionUser | null = null;

  if (env.demoMode) {
    // Demo path — authenticate against bundled seed users (no DB required).
    const u = findDemoUserByEmail(email);
    if (u && u.password === password) {
      sessionUser = {
        id: u.id,
        employeeNo: u.employeeNo,
        name: u.name,
        email: u.email,
        role: u.role,
        title: u.title,
        departmentId: `dept_${u.departmentCode.toLowerCase()}`,
        departmentName: u.departmentName,
        avatarColor: u.avatarColor,
      };
    }
  } else {
    // Production path — Prisma + bcrypt.
    const { prisma } = await import("@/lib/prisma");
    const u = await prisma.user.findFirst({
      where: { OR: [{ email: email.toLowerCase() }, { employeeNo: email }], isActive: true },
      include: { department: true },
    });
    if (u && (await verifyPassword(password, u.passwordHash))) {
      await prisma.user.update({ where: { id: u.id }, data: { lastLoginAt: new Date() } });
      sessionUser = {
        id: u.id,
        employeeNo: u.employeeNo,
        name: u.name,
        email: u.email,
        role: u.role as SessionUser["role"],
        title: u.title,
        departmentId: u.departmentId,
        departmentName: u.department?.name ?? null,
        avatarColor: u.avatarColor,
      };
    }
  }

  if (!sessionUser) {
    return NextResponse.json(
      { error: "بيانات الدخول غير صحيحة. تحقق من البريد/الرقم الوظيفي وكلمة المرور." },
      { status: 401 }
    );
  }

  const token = await signSession(sessionUser);
  await setSessionCookie(token);
  return NextResponse.json({ user: sessionUser });
}
